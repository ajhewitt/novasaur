typedef int int16_t;
typedef unsigned int uint16_t;
typedef unsigned int word;
typedef unsigned char uint8_t;
typedef unsigned char byte;
