void copyIp (byte *dst, const byte *src);
void copyMac (byte *dst, const byte *src);
