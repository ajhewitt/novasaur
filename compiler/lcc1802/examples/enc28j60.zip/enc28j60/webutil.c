void copyIp (byte *dst, const byte *src) {
    memcpy(dst, src, 4);
}

void copyMac (byte *dst, const byte *src) {
    memcpy(dst, src, 6);
}

